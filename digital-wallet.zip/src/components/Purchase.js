
import '../assets/css/main.css';
import '../assets/css/style.css';
import Nav from "./Nav";
import Footer from "./Footer";

export default function Purchase(){
    return(
        <div>
        <Nav />

        <div class="circle-charts max-theme-width">
      <div class="circle-chart">
        <div class="circle-chart-details">
          <div class="percent-div">25%</div>
          <div class="content">
            <div class="left-circle">
              <div class="main-circle"></div>
            </div>
            <div class="right-content">
              <div class="details">
                <p>Contact</p>
                <h4>0x5D9C...3ba4</h4>
              </div>
              <div class="details">
                <p>Amount</p>
                <h4>200 USDC</h4>
              </div>
              <div class="details">
                <p>Date</p>
                <h4>Yesterday at 7:17PM</h4>
              </div>
            </div>
          </div>
        </div>
        <div class="circle-chart-details">
          <div class="percent-div">25%</div>
          <div class="content">
            <div class="left-circle">
              <div class="main-circle"></div>
            </div>
            <div class="right-content">
              <div class="details">
                <p>Contact</p>
                <h4>0x5D9C...3ba4</h4>
              </div>
              <div class="details">
                <p>Amount</p>
                <h4>200 USDC</h4>
              </div>
              <div class="details">
                <p>Date</p>
                <h4>Yesterday at 7:17PM</h4>
              </div>
            </div>
          </div>
        </div>
        <div class="circle-chart-details">
          <div class="percent-div">25%</div>
          <div class="content">
            <div class="left-circle">
              <div class="main-circle"></div>
            </div>
            <div class="right-content">
              <div class="details">
                <p>Contact</p>
                <h4>0x5D9C...3ba4</h4>
              </div>
              <div class="details">
                <p>Amount</p>
                <h4>200 USDC</h4>
              </div>
              <div class="details">
                <p>Date</p>
                <h4>Yesterday at 7:17PM</h4>
              </div>
            </div>
          </div>
        </div>
        <div class="circle-chart-details">
          <div class="percent-div">25%</div>
          <div class="content">
            <div class="left-circle">
              <div class="main-circle"></div>
            </div>
            <div class="right-content">
              <div class="details">
                <p>Contact</p>
                <h4>0x5D9C...3ba4</h4>
              </div>
              <div class="details">
                <p>Amount</p>
                <h4>200 USDC</h4>
              </div>
              <div class="details">
                <p>Date</p>
                <h4>Yesterday at 7:17PM</h4>
              </div>
            </div>
          </div>
        </div>
        <div class="circle-chart-details">
          <div class="percent-div">25%</div>
          <div class="content">
            <div class="left-circle">
              <div class="main-circle"></div>
            </div>
            <div class="right-content">
              <div class="details">
                <p>Contact</p>
                <h4>0x5D9C...3ba4</h4>
              </div>
              <div class="details">
                <p>Amount</p>
                <h4>200 USDC</h4>
              </div>
              <div class="details">
                <p>Date</p>
                <h4>Yesterday at 7:17PM</h4>
              </div>
            </div>
          </div>
        </div>
        <div class="circle-chart-details">
          <div class="percent-div">25%</div>
          <div class="content">
            <div class="left-circle">
              <div class="main-circle"></div>
            </div>
            <div class="right-content">
              <div class="details">
                <p>Contact</p>
                <h4>0x5D9C...3ba4</h4>
              </div>
              <div class="details">
                <p>Amount</p>
                <h4>200 USDC</h4>
              </div>
              <div class="details">
                <p>Date</p>
                <h4>Yesterday at 7:17PM</h4>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


        <Footer />

        </div>
    )
}